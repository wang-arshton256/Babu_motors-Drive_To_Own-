<script type="text/javascript">

$(function () {
  bsCustomFileInput.init();
});
</script>
