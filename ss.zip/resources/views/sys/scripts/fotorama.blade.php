<script type="text/javascript">
$(function () {
  $('.fotorama').fotorama();
});
</script>
