<!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      Web based service portal
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2021 <a href="">Babu Motors</a>.</strong> All rights reserved. Designed by Wangutusi Arshton (wangarshtonl4@gmail.com)
  </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->
@include('sys.scripts.scripts')

</body>
</html>
